<?php
$con=mysqli_connect("localhost","root","password") or die("Failed to connect with database");
mysqli_select_db($con, "affecttutor");

//MySQL query start
$sql="SELECT * 
FROM googlechart";

//MySQL query end

//Result start
$result = mysqli_query($con,$sql) or die(mysqli_error($con));
//Result end

//Rows start
$rows = array();
//Rows end

$flag = true;

//Table start
$table = array();
$table1 = array();
//Table end

//Table Column array start
$table['cols'] = array(

    // Labels for your chart, these represent the column titles
    // Note that one column is in "string" format and another one is in "number" format as pie chart only required "numbers" for calculating percentage and string will be used for column title
    array('label' => 'Topics', 'type' => 'string'),
    array('label' => 'Percentage', 'type' => 'number')

);
//Table Column array end

//Table Row array start
$rows = array();
while($r = mysqli_fetch_assoc($result)) {
    $temp = array();
    // the following line will be used to slice the Pie chart
    $temp[] = array('v' => (string) $r['weekly_task']);

    // Values of each slice
    $temp[] = array('v' => (int) $r['percentage']);
    $rows[] = array('c' => $temp);
}

//Table Row array end

//Table Row start
$table['rows'] = $rows;
//Table Row end

//json start
$jsonTable = json_encode($table);

//json end
?>

<script type="text/javascript">

    google.load('visualization', '1', {'packages':['corechart']});
    //google.charts.load('current', {packages: ['corechart']});

    //Chart (Hardest Topics decided by Students)
    google.setOnLoadCallback(drawChart)

    //google.charts.setOnLoadCallback(drawChart);
    function drawChart() {

        // Create our data table out of JSON data loaded from server.
        var data = new google.visualization.DataTable(<?=$jsonTable?>);

        var options = {
            title: '',
            is3D: 'true'
        };
        var chart = new google.visualization.PieChart(document.getElementById('chart_div'));

        chart.draw(data, options);
    }
</script>
